import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OneTest {

	WebDriver driver;

	  @Before
	  public void setUp(){
	    driver = new FirefoxDriver();
	    driver.get("http://globaldc.oracle.com");
	  }

//	  @After
//	  public void tearDown(){
//	  driver.quit();
//	  }

	  @Test
	  public void testExamples(){
	    WebElement element = driver.findElement(By.linkText("Login"));
	    element.click();
	    WebElement element1 = driver.findElement(By.xpath("//*[@id='sso_username']"));
	    element1.sendKeys("fazil.hassan@oracle.com");
	    WebElement element2 = driver.findElement(By.xpath("//*[@id='ssopassword']"));
	    element2.sendKeys("Unme1431#");
	    WebElement element3 = driver.findElement(By.xpath("html/body/div[2]/div[2]/div[1]/div/form/ul/li[4]/a"));
	    element3.click();
	  }
	}