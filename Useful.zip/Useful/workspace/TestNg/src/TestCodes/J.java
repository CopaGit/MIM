package TestCodes;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class J {
	@Before
	public void before() {
		System.out.println("@Before");
		}
	
	@BeforeClass
	public static void beforeClass() {
		System.out.println("@BeforeClass");
	}
	
	@After
	public void after(){
		System.out.println("@After");
	}
	
	@AfterClass
	public static void afterClass(){
		System.out.println("@AfterClass");
	}
	
	
	@Test
	public void test1(){
		System.out.println("test1");
	}
	
	@Test
	public void test2() {
		System.out.println("test2");
	}
	
	@Test
	public void test3() {
		System.out.println("test3");
	}
}
