package TestCodes;

import org.junit.After;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;

import org.junit.Test;
import org.junit.runners.MethodSorters;



@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Junit {

	@Before
	public void before() {
		System.out.println("@Before");
		}
	
	@BeforeClass
	public static void beforeClass() {
		System.out.println("@BeforeClass");
	}
	
	@After
	public void after(){
		System.out.println("@After");
	}
	
	@AfterClass
	public static void afterClass(){
		System.out.println("@AfterClass");
	}
	
	

	
	
	
	
	@Test
	public void _4_b() {
		System.out.println("test4");
	}
	
	
	
	@Test
	public void _5_a() {
		System.out.println("test5");
	}
	
	
	@Test
	public void _3_c() {
		System.out.println("test3");
	}
	
	
	@Test
	public void _1_e(){
		System.out.println("test1");
	}
	
	@Test
	public void _2_d() {
		System.out.println("test2");
	}
}
