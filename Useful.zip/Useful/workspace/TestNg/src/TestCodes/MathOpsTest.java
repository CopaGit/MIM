package TestCodes;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Code.MathOps;

@SuppressWarnings("unused")
@Test
public class MathOpsTest {
	@BeforeSuite
	public void beforeSuite () {
		System.out.println("before suite");
	}
	@AfterSuite
	public void afterSuite() {
		System.out.println("after suite");
	}
	@BeforeClass
	public void beforeClass() {
		System.out.println("before class");
	}
	@AfterClass
	public void afterClass() {
		System.out.println("after class");
	}
    @BeforeTest
    public void beforeTest() {
    	System.out.println("before test");
    }
    @AfterTest
    public void afterTest() {
    	System.out.println("after test");
    }
    @BeforeMethod(alwaysRun=true)
    public void beforeMethod() {
    	System.out.println("before method");
    }
    @AfterMethod(alwaysRun=true)
    public void afterMethod() {
    	System.out.println("after method");
    }
    //@Parameters({"x","y"}) //parameters are passed from Math
    @Test(priority=1, dataProvider = "testdata")
    public void Add(int x, int y) {
    	MathOps m = new MathOps();
    	Assert.assertEquals(m.Add(x, y), 2);
    	System.out.println("in Add");
    }
    @Test(priority=4, alwaysRun=true)
    public void Divide() {
    	MathOps m = new MathOps();
    	Assert.assertEquals(m.Divide(5, 1), 5.0);
    	System.out.println("in Divide");
    }
    @Test(priority=3, dependsOnMethods={"Add"}, alwaysRun=true)
    public void Multiply() {
    	MathOps m = new MathOps();
    	Assert.assertEquals(m.Multiply(2, 3), 6);
    	System.out.println("in multiply");
    }
    @Test(priority=2, enabled=false)
    public void Subtract() {
    	MathOps m = new MathOps();
    	Assert.assertEquals(m.Subtract(5, 1), 4);
    	System.out.println("in subtract");
    }
    
    @DataProvider(name ="testdata")
    public Object [] [] createData() {
    	Object [] [] testdata = new Object [] [] { {10, 20} , {30, 40} };
    	return testdata;
    }
  
    }
