package Code;

public class MathOps {

	int x, y;
	public int Add(int a, int b) {
		return a+b;
	}
	public int Subtract(int a , int b) {
		return a-b;
	}
	public int Multiply (int a, int b) {
		return a*b;
	}
	public double Divide (int a, int b ) {
		return a/b;
	}
}
