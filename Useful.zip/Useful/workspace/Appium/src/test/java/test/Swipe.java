package test;

import static test.UI_Elements.emailId;
import static test.UI_Elements.incident_DashBoard_Access_Denied_OK_button;
import static test.UI_Elements.key_Areas_Sub_Tab;
import static test.UI_Elements.login_Button;
import static test.UI_Elements.passwd;
import static test.UI_Elements.password_Field;
import static test.UI_Elements.scope_Level_Tab;
import static test.UI_Elements.user_Name_Field;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Swipe {

		AppiumDriver wd;
	
	@Before
	public void setUp() throws MalformedURLException {
		
		File app = new File("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Samsung");
		
		capabilities.setCapability("app", app.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
		capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
		capabilities.setCapability("noReset", true);
		
		wd = new AndroidDriver (new URL ("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//APP_LOGIN
		//entering the user_name
		wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
		//entering the password
		wd.findElement(By.xpath(password_Field)).sendKeys(passwd);
		//Clicking on the login button
		wd.findElement(By.xpath(login_Button)).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				
		//Clicking OK on the 'Access Denied' message
		wd.findElement(By.xpath(incident_DashBoard_Access_Denied_OK_button)).click();
		
		//clicking on the Scope and Level Tab
		wd.findElement(By.xpath(scope_Level_Tab)).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//clicking on the key areas sub tab
		wd.findElement(By.xpath(key_Areas_Sub_Tab)).click();
		
}

	@Test
	public void swip()
    {  
    wd.swipe(500, 1300, 500, 500, 3000);
	
	
}
	
	@After
	public void tearDown() {
		//wd.quit();
	}
	
}