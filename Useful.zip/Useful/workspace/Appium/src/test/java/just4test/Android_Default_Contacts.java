package just4test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.*;
import io.appium.java_client.android.AndroidDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;



import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

@SuppressWarnings("unused")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Android_Default_Contacts {

	AppiumDriver wd;
	
	@Before
	public void setUp() throws MalformedURLException {
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Android19");
		
		capabilities.setCapability("appPackage", "com.android.contacts");
		capabilities.setCapability("appActivity", "com.android.contacts.activities.PeopleActivity");
		
		wd = new AndroidDriver( new URL ("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	
	@Test
	public void contact_Test() {
		
		// Clicking on the 'Create a new contact' button
		wd.findElement(By.name("Create a new contact")).click();
		wd.navigate().back();
		wd.navigate().back();
		wd.swipe(53, 200, 290, 200, 3000);
		// Entering the name
		//wd.findElement(By.id("com.android.contacts:id/editors")).sendKeys("Fazil Hassan");
		
		// swipe
		
		
		
		// Clicking on 'Done' to save
		//wd.findElement(By.name("Done")).click();
	}
	
	
	@Ignore
	@Test
	public void swip()
    {  
	
    JavascriptExecutor js = (JavascriptExecutor) wd;
    HashMap<String, Double> swipeObject = new HashMap<String, Double>();
    swipeObject.put("startX", 4.0);
    swipeObject.put("startY", 144.0);
    swipeObject.put("endX", 0.0);
    swipeObject.put("endY", 0.0);
    swipeObject.put("duration", 1.8);
    js.executeScript("mobile: swipe", swipeObject);
     }
	
	@After
	public void tearDown() {
		wd.quit();
	}
}
