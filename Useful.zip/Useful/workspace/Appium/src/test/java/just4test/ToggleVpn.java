package just4test;

import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.DesiredCapabilities;



public class ToggleVpn {
	
public static AndroidDriver wd;
	
	@BeforeClass
	public static void VpnSetUp() throws MalformedURLException {
				
		
				//code for VPN client setUp()
				File app = new File ("B:\\Selenium\\mobile apps\\Android\\app.openconnect-1.apk");
				
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability("platformName", "Android");
				capabilities.setCapability("platformVersion", "4.4.2");
				capabilities.setCapability("deviceName", "Android19");
				
				capabilities.setCapability("app", app.getAbsolutePath());
				capabilities.setCapability("appPackage", "app.openconnect");
				capabilities.setCapability("appActivity", "app.openconnect.MainActivity");
				capabilities.setCapability("noReset", true);
				
				wd = new AndroidDriver (new URL ("http://127.0.0.1:4723/wd/hub"), capabilities);
				wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				
	}
				@Test
				public void connect() {
				
				
				//code for creating Oracle VPN profile to connect
				//Clicking on the '+' button at the bottom of the screen to add the server name
				wd.findElement(By.name("Add")).click();
				//Entering the server name details
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")).sendKeys("myaccess.oraclevpn.com");
				//Then, clicking 'OK' button
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.Button[2]")).click();
				//Now, navigating one (screen) activity back
				wd.navigate().back();
				//Clicking on the Oracle VPN option
				wd.findElement(By.xpath("//android.view.View[1]/android.widget.FrameLayout[2]/android.widget.LinearLayout[1]/android.widget.ListView[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")).click();
				
				// conditional code for whether to select 'I trust the connection' or
				//to proceed to click 'Just now' button
					
				
				boolean isCheckBoxPresent;
				try {
				wd.findElement(By.id("com.android.vpndialogs:id/check"));
				   isCheckBoxPresent = true;
				} catch (NoSuchElementException e) {
					isCheckBoxPresent = false;
				}
				if (isCheckBoxPresent) {
					// 1_Clicking on the 'I trust this application' checkBox.
					wd.findElement(By.id("com.android.vpndialogs:id/check")).click();
					// 2_Clicking on OK below the 'I trust this application' checkBox.
					wd.findElement(By.id("android:id/button1")).click();
					// 3_Then, clicking on the 'Just Once' button, finally.
					wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.Button[2]")).click();
				}
				else {
				//Clicking on the 'Just Once' button, directly.
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.Button[2]")).click();
				}
				
				
				//Entering the VPN user_name
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")).sendKeys("fhassan_in");
				//Entering the password
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[2]/android.widget.EditText[1]")).sendKeys("Yyyy1431#");
				//Un_checking the save password check_box
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.CheckBox[1]")).click();
				//Clicking on the 'OK' button to connect to VPN
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.Button[2]")).click();

				}
				
				
				
				@After
				public void tearDown() {
				wd.quit();
				}
}
