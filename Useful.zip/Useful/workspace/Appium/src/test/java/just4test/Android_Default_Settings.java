package just4test;

import io.appium.java_client.android.AndroidDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;


public class Android_Default_Settings {

	AndroidDriver wd;
	
	@Before
	public void setUp() throws MalformedURLException {
		
		//File app = new File ("B:\\Settings.apk");
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Android 19");
		
		//capabilities.setCapability("app", app.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.android.settings");
		capabilities.setCapability("appActivity", "com.android.settings.Settings");
		
		wd = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	@Test
	public void settings_Test() {
		// Clicking on the 'More' button
		wd.findElement(By.name("More�")).click();
		// Clicking on the 'Mobile Networks' button
		wd.findElement(By.name("Mobile networks")).click();
		// Clicking on the 'Access Point Names' button
		wd.findElement(By.name("Access Point Names")).click();
		
		
	}
	
	@After
	public void tearDown() {
		wd.quit();
	}
}
