package main;



import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class MobileMimTest {
 public static AndroidDriver dr;
	
	@BeforeClass
	public static void setUp() throws MalformedURLException, InterruptedException 
	{
		File app = new File("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
		capabilities.setCapability("deviceName", "Android 19");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("platformName", "Android");
		
		capabilities.setCapability("app", app.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
		capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
		
		dr = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		dr.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	@Test
	public void loginTest() throws Exception{
		//enter the user name text
		WebElement uName = dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/usernameET"));
		uName.sendKeys("fazil.hassan@oracle.com");
		//enter the password  
		WebElement passwd = dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/passwordET"));
		passwd.sendKeys("Unme1431#");
		//tap the login button
		WebElement lbutton = dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/LoginbuttonBT"));
		lbutton.click();
		dr.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//unable to access activity
		dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/button1")).click();
		
				}
	@Test
	public void scopeTest() throws Exception {
		//click on the Scope and Level Tab
		dr.findElement(By.name("Scope & Level")).click();
		//click on the 'Key Areas' button
		dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/button3")).click();
		//click on the 'Levels' button
		dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/button2")).click();
		//click on 'Definition' button
		dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/button1")).click();
		//click on Engagement and Escalation tab
		dr.findElement(By.name("Engagement & Escalation")).click();
		//click on Incident DashBoard tab
		dr.findElement(By.name("Incident Dashboard")).click();
	}
			

	@Test
	public void logoutTest() throws Exception {
		//click on logout button
		dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/logoutImage")).click();
		//click on the yes button
		dr.findElement(By.id("com.oraclecorp.eus.mobilemim:id/button1")).click();
		}
	
	@Ignore
	@Test
	public void testcase() throws Exception {
		this.loginTest();
		this.scopeTest();
		this.logoutTest();
	}
	
	@AfterClass
	public static void tearDown() throws Exception {
		dr.quit();
	}
	
}

