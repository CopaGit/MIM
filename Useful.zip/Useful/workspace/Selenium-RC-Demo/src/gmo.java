import com.thoughtworks.selenium.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.regex.Pattern;
	
@SuppressWarnings("unused")

public class gmo {

		@SuppressWarnings("deprecation")
		private Selenium selenium;

		@SuppressWarnings("deprecation")
		@Before
		public void setUp() throws Exception {
			selenium = new DefaultSelenium("localhost", 4444, "*chrome", "http://demo.borland.com");
			selenium.start();
		}

		@SuppressWarnings("deprecation")
		@Test
		public void testUntitled() throws Exception {
			selenium.open("/gmopost/");
			selenium.click("name=bSubmit");
			selenium.waitForPageToLoad("50000");
			selenium.type("name=QTY_SOCKS", "1");
			selenium.type("name=QTY_BOOTS", "1");
			selenium.click("name=bSubmit");
			selenium.waitForPageToLoad("30000");
			selenium.click("name=bSubmit");
			selenium.waitForPageToLoad("30000");
			selenium.type("name=billName", "Fazil");
			selenium.type("name=billAddress", "Jayanagar");
			selenium.type("name=billCity", "Bangalore");
			selenium.type("name=billState", "Karnataka");
			selenium.type("name=billZipCode", "12345");
			selenium.type("name=billPhone", "1234512345");
			selenium.type("name=billEmail", "fas_saf28@yahoo.com");
			selenium.type("name=CardNumber", "1234-1234-1234-1234");
			selenium.type("name=CardDate", "11/14");
			selenium.click("name=shipSameAsBill");
			selenium.click("name=bSubmit");
			assertEquals("Please enter a valid card number of the form '1234-123456-12345' in this field.", selenium.getAlert());
			selenium.click("name=bSubmit");
			assertEquals("Please enter a valid card number of the form '1234-123456-12345' in this field.", selenium.getAlert());
		}

		@After
		public void tearDown() throws Exception {
			//selenium.stop();
		}
	}
