import java.awt.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;


@SuppressWarnings("unused")
public class gmo1 {

	public static void main(String args[]){
		String browser="firedfox";
		WebDriver wd=null;
		if(browser == "firefox") {
		ProfilesIni pi = new ProfilesIni();	
		FirefoxProfile fp = pi.getProfile("default");
		wd = new FirefoxDriver(fp);
		
		} else if (browser=="chrome") {
			System.setProperty("webdriver.chrome.driver", "B:\\SELENIUM\\chromedriver_win32\\chromedriver.exe");
            wd=new ChromeDriver();
		}
		else {
			System.setProperty("webdriver.ie.driver", "B:\\SELENIUM\\IEDriverServer.exe");
			wd=new InternetExplorerDriver();
	}
	wd.manage().window().maximize();
		
		homePage(wd);
		catalog(wd);
		PlaceOrder(wd);
		BillInfo(wd);
		Receipt(wd);
		close(wd);
		}
	
	public static void homePage(WebDriver wd){
		wd.get("http://demo.borland.com/gmopost/");
		String page_title=wd.getTitle();
		System.out.println("Home page title:"+page_title);
		WebElement enterbutton=wd.findElement(By.name("bSubmit"));
		enterbutton.click();
		wd.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
	}
	public static void catalog(WebDriver wd){
		WebElement qtyTents=wd.findElement(By.cssSelector("[name='QTY_TENTS']"));
		qtyTents.clear();
		qtyTents.sendKeys("2");
		WebElement orderbutton=wd.findElement(By.name("bSubmit"));
		orderbutton.click();
		wd.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
	}
	
	public static void PlaceOrder(WebDriver wd){
		wd.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		WebElement placeorder=wd.findElement(By.name("bSubmit"));
		placeorder.click();
		wd.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		
	}
	public static void  BillInfo(WebDriver wd){
		wd.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
		WebElement Billname=wd.findElement(By.name("billName"));
		Billname.sendKeys("Jagan");
		WebElement BillAddress=wd.findElement(By.name("billAddress"));
		BillAddress.sendKeys("Bangalore");
		WebElement billCity=wd.findElement(By.name("billCity"));
		billCity.sendKeys("Bangalore");
		WebElement billState=wd.findElement(By.name("billState"));
		billState.sendKeys("Karnataka");
		WebElement billZipCode=wd.findElement(By.name("billZipCode"));
		billZipCode.sendKeys("12345");
		
		WebElement shipPhone=wd.findElement(By.name("billPhone"));
		shipPhone.sendKeys("1234567890");
		
		WebElement billEmail=wd.findElement(By.name("billEmail"));
		billEmail.sendKeys("ab1c@gmail.com");
		wd.manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);
		
		WebElement CardType=wd.findElement(By.name("CardType"));
		CardType.sendKeys("Visa");
		
		//Select card= new Select(CardType);
		//List<WebElement>options = card.getOptions();
		
		//card.selectByVisibleText("Visa");
		
		WebElement CardNumber=wd.findElement(By.name("CardNumber"));
		CardNumber.sendKeys("1234567867564567");
		
		WebElement CardDate=wd.findElement(By.name("CardDate"));
		CardDate.sendKeys("12/15");
		
		WebElement shipto=wd.findElement(By.name("shipSameAsBill"));
		shipto.click();
		
		WebElement placetheorder=wd.findElement(By.name("bSubmit"));
		placetheorder.click();
		wd.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		
	}
	public static void Receipt(WebDriver wd){
		WebElement Reciptbutton=wd.findElement(By.name("bSubmit"));
		Reciptbutton.click();
		wd.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		
}
	public static void close (WebDriver wd){
		wd.close();
	}
}



















/*import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.support.ui.Select;


public class gmo1 {

	
	public static void main(String [] args) {
		ProfilesIni pi = new ProfilesIni();	
		FirefoxProfile fp = pi.getProfile("default");
		WebDriver wd = new FirefoxDriver(fp);
		wd.manage().window().maximize();
		homepage(wd);
		catalog(wd);
		placeOrder(wd);
		receipt(wd);
		closeapp(wd);		
	}
	public static void homepage(WebDriver wd) {
		wd.get("http://demo.borland.com/gmopost/");
		String page_title=wd.getTitle();
		System.out.println("home page title:" + page_title);
		WebElement enterButton = wd.findElement(By.name("bSubmit"));
		enterButton.click();
		wd.manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);
	}
	
	public static void catalog(WebDriver wd) {
		WebElement qtyTents = wd.findElement(By.name("QTY_TENTS"));
		qtyTents.clear();
		qtyTents.sendKeys("2");
		WebElement orderButton = wd.findElement(By.xpath("//input[@value='Place An Order']"));
		orderButton.click();
		wd.manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);		
		}
	
	
	public static void placeOrder(WebDriver wd) {
		WebElement po = wd.findElement(By.xpath("//input[@value ='Proceed With Order']"));
		po.click();
		wd.manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);
				}
	
	public static void  BillInfo(WebDriver wd){
        WebElement Billname=wd.findElement(By.name("billName"));
        Billname.sendKeys("Jagan");
        WebElement BillAddress=wd.findElement(By.name("billAddress"));
        BillAddress.sendKeys("Bangalore");
        WebElement billCity=wd.findElement(By.name("billCity"));
        billCity.sendKeys("Bangalore");
        WebElement billState=wd.findElement(By.name("billState"));
        billState.sendKeys("Karnataka");
        WebElement billZipCode=wd.findElement(By.name("billZipCode"));
        billZipCode.sendKeys("12345");
        WebElement billEmail=wd.findElement(By.name("billEmail"));
        billEmail.sendKeys("ab1c@gmail.com");
        String sCardType = selectCardType(wd);
        we=wd.findElement(By.name("CardNumber"));
        
        
	}
	
	public static String selectCardType(WebDriver ff) {
		WebElement cardType = ff.findElement(By.name("cardType"));
		Select selectCard = new Select(cardType);
		List<WebElement> options = selectCard.getOptions();
		int elementSize = options.size();
		int randVal = (int) (Math.random()*elementSize);
		selectCard.selectByIndex(randVal);
		String valueSelected=cardType.getAttribute("value");
		System.out.println("Card Type selected:" + valueSelected);
		return valueSelected;
		//cardType.selectByVisibleText("Visa");
	}
	
	
	public static void receipt (WebDriver wd) {
		 WebElement returnhome= wd.findElement(By.name("bSubmit"));
		returnhome.click();
	}
	public static void closeapp(WebDriver wd) {
		wd.close();
	}
}
*/

