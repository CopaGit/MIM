package selenium.safari.course;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.interactions.Actions;

public class SeleniumBasicInteractions {
	
	
	
	
	public static void main (String [] args) {
		WebDriver wd;
		ProfilesIni allProfiles = new ProfilesIni();
		FirefoxProfile myProfile = allProfiles.getProfile("Selenium");
		wd = new FirefoxDriver(myProfile);
		wd.get("http://www.google.co.in");
		WebElement searchBox = wd.findElement(By.name("q"));
		searchBox.sendKeys(Keys.chord(Keys.SHIFT, "Packt Publishing"));
		//searchBox.clear();
		System.out.println(searchBox.getText());
		System.out.println(searchBox.getAttribute("name"));
		System.out.println(searchBox.getAttribute("id"));
		System.out.println(searchBox.getAttribute("class"));
		System.out.println(searchBox.getLocation());
		System.out.println(searchBox.getSize());
		System.out.println(searchBox.getCssValue("background-color"));
		System.out.println(searchBox.getClass());
		System.out.println(searchBox.getTagName());
		System.out.println(searchBox.isDisplayed());
		System.out.println(searchBox.isSelected());
		System.out.println(searchBox.isEnabled());
		
		List<WebElement> buttons = wd.findElements(By.tagName("button"));
		System.out.println(buttons.size());
		
		WebElement submitButton = wd.findElement(By.xpath("//*[@id='gbqfb']"));
		System.out.println("X point: " + submitButton.getLocation().getX() + "   Y point: " + submitButton.getLocation().getY());
		Actions builder = new Actions(wd);
		builder.moveByOffset(submitButton.getLocation().getX()+1, submitButton.getLocation().getX()+1).click();
		builder.build().perform();
		
		//wd.quit();
	}
	
	
}
