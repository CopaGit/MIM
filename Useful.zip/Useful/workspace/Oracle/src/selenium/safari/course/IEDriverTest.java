package selenium.safari.course;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class IEDriverTest {

	public static void main (String []args){
		
	WebDriver wd;
	System.setProperty("webdriver.ie.driver", "B:\\Selenium\\IEDriverServer.exe");
	wd = new InternetExplorerDriver();
	wd.get("http://www.google.co.in");
	
	
	
	}
}
