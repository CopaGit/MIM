package selenium.safari.course;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;

@SuppressWarnings("unused")
public class ActionsBuildPerform {

	public static void main (String [] args) {
		
//		DesiredCapabilities capabilities = new DesiredCapabilities();
//		capabilities.setCapability("takesScreenshot", true);
		
		ProfilesIni allProfiles = new ProfilesIni();
		FirefoxProfile myProfile = allProfiles.getProfile("Selenium");
		try {
			myProfile.addExtension(new File("C:\\Users\\fhassan\\Desktop\\selenium-ide-2.8.0.xpi"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		myProfile.setPreference("general.useragent.override", "Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7");
		WebDriver wd = new FirefoxDriver(myProfile);
		wd.get("https://www.google.co.in");
		wd.manage().window().maximize();
		String window1 = wd.getWindowHandle();
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		wd.findElement(By.xpath("html/body/form/table[2]/tbody/tr/td[2]/table/tbody/tr[1]/td[1]/span[3]/p/a")).click();
//		String window2 = wd.getWindowHandle();
//		wd.switchTo().window(window1);
//		wd.findElement(By.name("fldLoginUserId")).sendKeys("Hello");
		System.out.println(window1);
		
		
		
		
		
	}
}
