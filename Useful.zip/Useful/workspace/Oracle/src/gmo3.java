import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;


public class gmo3 {
	
	public static void main (String [] args) {
ProfilesIni pi = new ProfilesIni();	
@SuppressWarnings("unused")
FirefoxProfile fx = pi.getProfile("default");
FirefoxProfile fp = new FirefoxProfile();
fp.setEnableNativeEvents(true);
fp.setPreference("network.proxy.type",1); //manual proxy setting
fp.setPreference("network.proxy.http", "localhost"); // specify ip (or localhost)
fp.setPreference("network.proxy.http_port", 8080); //specify port
WebDriver ff = new FirefoxDriver(fp);
ff.get("http://www.google.com");
	}
}
