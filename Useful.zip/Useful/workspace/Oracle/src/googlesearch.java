import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;


public class googlesearch {

	public static void main (String []args) throws InterruptedException {
        ProfilesIni pi = new ProfilesIni();
        FirefoxProfile fp = pi.getProfile("anony");
        WebDriver wd = new FirefoxDriver(fp);   
	operation(wd);
	
	}
	
	public static void operation(WebDriver wd) throws InterruptedException {
        wd.get("http://www.google.co.in");
        wd.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
        wd.manage().window().maximize();
        wd.findElement(By.cssSelector("#gbqfq")).sendKeys("selenium");
        try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        wd.findElement(By.cssSelector("#gbqfq")).sendKeys(Keys.DOWN);
        try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        wd.findElement(By.cssSelector("#gbqfq")).sendKeys(Keys.DOWN);
        try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        wd.findElement(By.cssSelector("#gbqfq")).sendKeys(Keys.DOWN);
        Thread.sleep(2000);
        wd.findElement(By.cssSelector("#gbqfq")).sendKeys(Keys.UP);
        Thread.sleep(2000);
        wd.findElement(By.cssSelector(".gbqfif")).sendKeys(Keys.UP);
   wd.quit();
	}
}
