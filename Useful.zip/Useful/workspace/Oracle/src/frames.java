import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;


public class frames {

	
	public static void main (String[]args) {
		ProfilesIni pi = new ProfilesIni();	
		FirefoxProfile fp = pi.getProfile("default");
		WebDriver driver = new FirefoxDriver(fp);
		driver.get("http://selenium.googlecode.com/git/docs/api/java/index.html");
		List<WebElement>framesList=driver.findElements(By.tagName("frame"));
		System.out.println(framesList.size());
		for (WebElement frame:framesList) {
		String frameName=frame.getAttribute("name");
		System.out.println("---");
		System.out.println(frameName);
		System.out.println("---");
		driver.switchTo().frame(frameName);
		
		
		//driver.switchTo().frame("packageListFrame");
		List<WebElement> packagesList = driver.findElements(By.tagName("a"));
		for (WebElement packages:packagesList) {
			System.out.println(packages.getText());
		}
				driver.switchTo().defaultContent();
	}
	//driver.quit();
}
}