	package javaSE7_course;

import java.util.ArrayList;

public class Raw {

	public int [] vacationDays;
	public int yearsOfService;
	
	
	public ArrayList<String> theList = new ArrayList<String>();
	
	
	public void setvacationScale() {
		vacationDays = new int [7];
		vacationDays[0] = 10;
		vacationDays[1] = 15;
		vacationDays[2] = 15;
		vacationDays[3] = 15;
		vacationDays[4] = 20;
		vacationDays[5] = 20;
		vacationDays[6] = 25;
	}
	
	
	
	@SuppressWarnings({ })
	public void setListValues() {
		
		theList.add("A B");
		theList.add("C D");
		theList.add("E F");
		theList.add("G H");
	}
	
	public void displayList() {
		System.out.println("The values of the list are  " + theList);
		System.out.println("The size of the list is " + theList.size() );
	}

	public void manipulateList() {
		System.out.println("----------------------");
		theList.remove("C D");
		System.out.println(theList);
		System.out.println(theList.size());
		System.out.println("----------------------");
		theList.add(1, "Fazil Hassan");
		System.out.println(theList);
		System.out.println(theList.size());
	}

	
	
	
	public void forLoop() {
		int [] array1 = new int [5];
		for (int i=0; i < array1.length; i++) {
		array1[i]=3;	
		System.out.println(array1[i]);
		}
	}
	
	public void vacationScaleTwo() {
		ArrayList<Integer> vacationDayss;
		vacationDayss = new ArrayList<Integer>(7);
		vacationDayss.add(10);
		vacationDayss.add(15);
		vacationDayss.add(15);
		vacationDayss.add(15);
		vacationDayss.add(20);
		vacationDayss.add(20);
		vacationDayss.add(25);
		
	for(int years = 0; years < vacationDayss.size(); years ++) {
		System.out.println("The vacation days for " + years + " years of service is: " + vacationDayss.get(years));
	}
	}

	
	public void namesListTwo() {
		ArrayList<String> names = new ArrayList<String>();
		names.add("Joe Smith");
		names.add("Mary Palmer");
		names.add("Jose Gonzales");
		names.add("Linda Baker");
		int index = 0;
		for (String name: names) {
			System.out.println("The name at index " + index + " is: " + name);
			++index;
		}
	}





	public void switchString(String input){
		switch(input){
		case "a" : System.out.println( "apple" );
		case "b" : System.out.println( "bat" );
		break;
		case "B" : System.out.println( "big bat" );
		break;
		default : System.out.println( "none" );
		}
		










	}

}
