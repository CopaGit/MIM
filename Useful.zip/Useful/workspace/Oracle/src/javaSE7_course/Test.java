package javaSE7_course;

public class Test {

	
	public static void main (String [] args) {
		Raw o1 = new Raw();
//		o1.setListValues();
//		o1.displayList();
//		o1.manipulateList();
		//o1.forLoop();
		//o1.vacationScaleTwo();
		//o1.namesListTwo();
		o1.switchString("ddd");
	
		
		
		
	}
}
