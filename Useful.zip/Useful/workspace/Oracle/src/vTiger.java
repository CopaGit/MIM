import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class vTiger {

	public static void main (String []args) {
		ProfilesIni pi = new ProfilesIni();
		FirefoxProfile fp = pi.getProfile("anony");
		WebDriver wd = new FirefoxDriver(fp);
		wd.get("http://localhost:8888/index.php?action=Login&module=Users");
		wd.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		wd.findElement(By.xpath("//input[@name='user_name']")).sendKeys("admin");
		wd.findElement(By.xpath("//input[@name='user_password']")).sendKeys("admin");
		wd.findElement(By.xpath(".//*[@id='submitButton']")).click();
		wd.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		WebElement menu = wd.findElement(By.xpath("html/body/table[2]/tbody/tr/td[2]/table/tbody/tr/td[22]/a"));
		Actions mouse_actions = new Actions(wd);
		mouse_actions.moveToElement(menu).perform();
		WebDriverWait wait = new WebDriverWait(wd, 5);
		WebElement vendor = wd.findElement(By.xpath(".//*[@id='more' and contains(text(),'Vendors')]"));
		WebElement ele = wait.until(ExpectedConditions.visibilityOf(vendor));
		mouse_actions.moveToElement(ele).click().perform();
		
		
		/* to find text presence
		 * 
		 * WebElement homepagetext=wd.findElement(By.xpath(".//*[@id='post-386']/div[1]/h2"));
	
	if(homepagetext.getText()=="Online Selenium Training")
		System.out.println("home page text has found");
	else 
		System.out.println("home page text has not found");
		*/
		
		 
	}
}
