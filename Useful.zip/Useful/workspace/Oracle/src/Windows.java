import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;


public class Windows {

	public static void main (String [] args) throws InterruptedException{
		ProfilesIni pi = new ProfilesIni();	
		FirefoxProfile fp = pi.getProfile("default");
		WebDriver driver = new FirefoxDriver(fp);
		driver.manage().window().maximize();
		driver.get("http://www.expedia.co.in");
		
		//Click on Feedback
		WebElement eleFeedback= driver.findElement(By.xpath(".//*[@id='nav-tool-feedback']"));
		eleFeedback.click();
		//((JavascriptExecutor)driver).executeScript("arguments[0].click()",eleFeedBack);
		//driver.findElement(By.xpath("//*[@id='nav-tool-feedback']")).click();
		Set<String> handles = driver.getWindowHandles();
		String mainWin = driver.getWindowHandle();
		System.out.println("mainWin:" + mainWin);
		handles.remove(mainWin);
		String feedbkWin = handles.iterator().next();
		System.out.println("feedbkWin:" + feedbkWin);
		Thread.sleep(4000);
		//This will switch windows control to the other window and click submit button
		driver.switchTo().window(feedbkWin);
		driver.findElement(By.xpath(".//*[@id='headerFeedback']/div[4]/div")).click();
		// click on 'click here' link on comment card page
		driver.findElement(By.cssSelector("#CSLink a")).click();
		Set<String> newHandles = driver.getWindowHandles();
		System.out.println(newHandles.size());
		String[] winHandle = new String[newHandles.size()];
		int i=0;
		for (String handle:newHandles){
			winHandle[i]=handle;
			System.out.println(winHandle[i]);
			i++;
		}
		System.out.println("------");
		for(i=winHandle.length-1; i>=0; i--){
			System.out.println(winHandle[i]);
			driver.switchTo().window(winHandle[i]);
			driver.close();
		}
		
	}
}
