import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;


public class gmo2 {
	public static void main (String []args) {
		ProfilesIni pi = new ProfilesIni();
		FirefoxProfile fp = pi.getProfile("anony");
		WebDriver wd = new FirefoxDriver(fp);
		//Calling Statements.
		openPage(wd);
	}
		public static void openPage(WebDriver wd) {
		wd.get("http://demo.borland.com/gmopost/");
		WebElement enter = wd.findElement(By.xpath("//input[contains(@value,'Enter GMO OnLine')]"));
		enter.click();	
	}
		
		}



/*import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;


public class gmo2 {

	public static void main (String [] args) {
		ProfilesIni pi = new ProfilesIni();
		FirefoxProfile fp = pi.getProfile("anony");
		WebDriver wd = new FirefoxDriver(fp);
	google(wd);
	}
		
		public static void google(WebDriver wd) {
	wd.get("http://www.google.co.in");
		}
		
		public static void close(WebDriver wd) {
			wd.close();
		}
	}

*/