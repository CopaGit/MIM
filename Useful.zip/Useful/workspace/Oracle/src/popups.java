import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;



public class popups {

	public static void main(String args[]) throws IOException {
		String browser="firefox";
		WebDriver wd=null;
		if(browser == "firefox") {
		ProfilesIni pi = new ProfilesIni();	
		FirefoxProfile fp = pi.getProfile("anony");
		wd = new FirefoxDriver(fp);
		
		} else if (browser=="chrome") {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\fhassan\\Desktop\\SELENIUM\\chromedriver.exe");
            wd=new ChromeDriver();
		}
		else {
			System.setProperty("webdriver.ie.driver", "C:\\Users\\fhassan\\Desktop\\SELENIUM\\IEDriverServer32.exe");
			wd=new InternetExplorerDriver();
	}
	wd.manage().window().maximize();
	
	Homepage(wd);
	//test(wd);
	//catalog(wd);
	//CheckInvalidEntry(wd);
	//captureScreenShot(wd, "FAS");
	test1(wd);
	}
	
	public static void Homepage(WebDriver wd){
		wd.get("http://demo.borland.com/gmopost/");
		String page_title=wd.getTitle();
		System.out.println("Home page title:"+page_title);
		WebElement enterbutton=wd.findElement(By.name("bSubmit"));
		enterbutton.click();
		wd.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
	}
	
	public static void catalog(WebDriver wd){
		WebElement qtyTents=wd.findElement(By.cssSelector("[name='QTY_TENTS']"));
		qtyTents.clear();
		qtyTents.sendKeys("0");
		
		boolean allOK=CheckInvalidEntry(wd);
		System.out.println("allOK " + allOK);
		
		// can also use this -> wd.findElement(By.xpath("//input{@type='submit...
		wd.findElement(By.name("bSubmit")).click();
		//captureScreenShot(wd,"AlertInvalidOrderQty");
		try {
			System.out.println("Message:" + wd.switchTo().alert().getText());
			wd.switchTo().alert().accept();
		} catch (NoAlertPresentException Ex) {
			System.out.println("alert was not present");
			if(!allOK) System.out.println("Error: alert should have been displayed");
		}
			
		WebElement orderbutton=wd.findElement(By.name("bSubmit"));
		orderbutton.click();
		wd.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		Alert alertPopup=wd.switchTo().alert();
		alertPopup.accept();
		}
	
	@SuppressWarnings("unused")
	private static void captureScreenShot(WebDriver wd, String scrname) throws IOException {
		//Take the screenshot of the popup and save this unique format 
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		File scrFile = ((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+ "\\ScreenShots\\"+scrname+dateFormat.format(date)+".jpg"));	
	}
	
	private static boolean CheckInvalidEntry(WebDriver wd) {
		int iflag = 0;
		//to run this method comment out the 'catalog' method-call under main method.
		List<WebElement>QuantityFields = wd.findElements(By.cssSelector("[type = 'text']"));
		
		for (WebElement inputElement:QuantityFields) {
			//print the Input Elements name and value entered in it
			String attrVal=inputElement.getAttribute("name");
			if (attrVal.equals("0")) {
				System.out.println("Check for 0, flag=1");
				if (iflag!=3)iflag=1;
			} else if (attrVal.matches("[a-zA-Z]+")) {
				System.out.println("check for [a-zA-Z], flag=2");
				iflag=2;
				break;
			}
			else if(attrVal.matches("[1-9]+")){
				iflag=3;
				System.out.println("check for 1-9");
			}
		}
		if(iflag ==3) return true;
		else return false;
			}
	
	public static void test(WebDriver wd){
		WebElement table=wd.findElement(By.xpath("//center/table"));
		List<WebElement> rows=table.findElements(By.xpath("tbody/tr"));
		
		for(WebElement row:rows){
			List<WebElement> columns =row.findElements(By.xpath("td"));
			for (WebElement col:columns){
				String hj =col.getText();
				System.out.println(hj);
			}
		}			
		}
	
	public static void test1 (WebDriver wd) {
		WebElement qtySocks=wd.findElement(By.cssSelector("[name='QTY_SOCKS']"));
		qtySocks.clear();
		qtySocks.sendKeys("3");
		List<WebElement>QuantityFields = wd.findElements(By.xpath("//input[@type='text']"));
		System.out.println(QuantityFields.size());
		for (int i =0; i<QuantityFields.size(); i++) {
			WebElement qtyField = QuantityFields.get(i);
			String qtyVal = qtyField.getAttribute("value");
			if (qtyVal.matches("[1-9]+")) {
				WebElement unitPriceElement = wd.findElement(By.xpath("//center/table/tbody/tr["+ (i+2) + "]/td[3]"));
				System.out.println("Unit Price : " + unitPriceElement.getText());
				//WebElement placeOrder = wd.findElement(By.xpath("//input[@type='submit']"));
			//	placeOrder.click();
			}
		}
	}
	
	
	
	
	}
