import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.support.events.EventFiringWebDriver;


public class ListenerDemo {
	

	public static void main (String[] args) throws InterruptedException {
		//TODO Auto-generated method stub
		ProfilesIni pi = new ProfilesIni();
		FirefoxProfile fp = pi.getProfile("anony");
		WebDriver ff = new FirefoxDriver(fp);
		EventFiringWebDriver driver = new EventFiringWebDriver(ff);
		//registering part
		customListener myListener = new customListener();
		driver.register(myListener);
		driver.manage().window().maximize();
		driver.navigate().to("http://demo.borland.com/gmopost");
		WebElement button = driver.findElement(By.xpath("//input[@name='bSubmit']"));
				
		button.click();
		moveBack(driver);
		moveForward(driver);
		driver.quit();
			
	}
	public static void moveBack(WebDriver driver) throws InterruptedException {
		try{
			driver.navigate().back();
			Thread.sleep(3000);
			System.out.println("alert present::: " + driver.switchTo().alert().getText());
			driver.switchTo().alert().accept();
		}catch (org.openqa.selenium.UnhandledAlertException uae){
			System.out.println(uae.getMessage());
					}
	}
	
	public static void moveForward (WebDriver driver) {
		try{
			driver.navigate().forward();
			System.out.println("alert Present: " + driver.switchTo().alert().getText());
			driver.switchTo().alert().accept();
		} catch (org.openqa.selenium.UnhandledAlertException uae) {
			System.out.println("StackTrace:" + uae.getStackTrace());
		}
	}
}
