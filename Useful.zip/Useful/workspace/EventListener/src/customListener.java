import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.AbstractWebDriverEventListener;


public class customListener extends AbstractWebDriverEventListener {
	
public void afterNavigateForward(WebDriver driver) {
	JavascriptExecutor executor = (JavascriptExecutor) driver;
	executor.executeScript("alert('Fazil, you have navigated forward');");
		}

public void afterNavigateBack (WebDriver driver) {
	JavascriptExecutor executor =(JavascriptExecutor) driver;
	executor.executeScript("alert('Fazil, you have navigated back');");
}

public void beforeClickOn (WebElement element, WebDriver driver) {
	System.out.println("You just Clicked " + element.getAttribute("value"));
}

public void afterClickOn (WebElement element, WebDriver driver) {
	System.out.println("you landed  in "+ driver.findElement(By.xpath("//h1[contains(text(),'OnLine')]")).getText());
}

public void afterChangeValueOf (WebElement element, WebDriver driver) {
	System.out.println("you have changed the value of :" + element.getAttribute("value"));
	
}
	
}


	

