package test;

public class PageCheckTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PageCheck pc = new PageCheck();
		pc.loadHomePage();
		pc.loadChapter(4);
		
		pc.shouldCheckButtonOnChapter2Page();
		pc.shouldCheckAnotherButtonOnChapter2Page();
	}

}
