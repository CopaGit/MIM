package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

@SuppressWarnings("unused")
public class PageCheck {
	
	
	//setting up firefox profile

	ProfilesIni pi = new ProfilesIni();	
	FirefoxProfile fp = pi.getProfile("default");
	WebDriver wd = new FirefoxDriver(fp);
	
	
	//open the home page
	public void loadHomePage(){
		wd.get("http://book.theautomatedtester.co.uk");
	}
	
	//Click Chapter-1
	public void loadChapter(int chNo) {
		wd.findElement(By.linkText("Chapter" + chNo)).click();
		System.out.println(wd.getTitle());
	
	//	if (!"Page 1".equals(wd.getTitle())){
	//  wd.get("http://book.theautomatedtester.co.uk/chapter2");}
		
	}
	
	
	public void shouldCheckButtonOnChapter2Page(){
	   Assert.assertEquals(wd.findElements( By.id("but1")).size(), 1);
	}
	    
	    public void shouldCheckAnotherButtonOnChapter2Page(){
	      Assert.assertEquals(wd.findElements(By.id("verifybutton")).size(), 1);
	    }
	
	//Assert method:
	 	//    public void shouldCheckButtonOnChapter2Page(){
	   	      //System.out.println(wd.findElement(By.id("but1")).getSize());
	    //}
	
	
}
