package FindingElements;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

public class TestChapter6 {

	WebDriver driver;
	
	@Before
	public void setUp() {
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("browser.startup.homepage", "http://book.theautomatedtester.co.uk/chapter4");
		driver = new FirefoxDriver(profile);
		//driver.get("http://book.theautomatedtester.co.uk/chapter4");
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}
	
	
	@Test
	public void testExamples()  {
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		 WebElement element1 = driver.findElement(By.xpath("//input[@id='nextBid']"));
		
		 element1.sendKeys("RF");
	}
	
}
