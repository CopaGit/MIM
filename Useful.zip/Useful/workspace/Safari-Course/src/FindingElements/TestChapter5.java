package FindingElements;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.internal.FindsByClassName;
import org.openqa.selenium.internal.FindsByCssSelector;
import org.openqa.selenium.internal.FindsById;
import org.openqa.selenium.internal.FindsByLinkText;
import org.openqa.selenium.internal.FindsByName;
import org.openqa.selenium.internal.FindsByXPath;

@SuppressWarnings("unused")
public class TestChapter5 {
	
	WebDriver driver;
	
	@Before
	public void setUp() {
		//ProfilesIni pi = new ProfilesIni();
		//FirefoxProfile fp = pi.getProfile("default");
		driver = new FirefoxDriver();
		driver.get("http://book.theautomatedtester.co.uk/chapter1");
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}
	
	@Test
	public void testExamples() {
		
		//FindsByID
		WebElement element1 = ((FindsById)driver).findElementById("verifybutton");
		//WebElement childElement = element.findElement(By.tagName("a"));
		List<WebElement> element2 = ((FindsById)driver).findElementsById("verifybutton");
		System.out.println(element2.size());
		Assert.assertEquals(element2.size(),1);
		
		//FindsByName
		WebElement element3 = ((FindsByName)driver).findElementByName("selected(1234)");
		List<WebElement> element4 = ((FindsByName)driver).findElementsByName("selected(1234)");
		Assert.assertEquals(1, element4.size());
	
		//FindsByClassName
		WebElement element5 = ((FindsByClassName)driver).findElementByClassName("storetext");
		List<WebElement> element6 = ((FindsByClassName)driver).findElementsByClassName("storetext");
		Assert.assertEquals(1, element6.size());
	
		//FindsByXpath
		WebElement element7 = ((FindsByXPath)driver).findElementByXPath("//input[@id='secondajaxbutton']");
		List<WebElement> element8 = ((FindsByXPath)driver).findElementsByXPath("//input[@id='secondajaxbutton']");
		Assert.assertEquals(1, element8.size());
		
		//FindsByCssSelector
		WebElement element9 = ((FindsByCssSelector)driver).findElementByCssSelector("#multiplewindow");
		List<WebElement> element10 = ((FindsByCssSelector)driver).findElementsByCssSelector(".multiplewindow");
		Assert.assertEquals(1, element10.size());
		
		//FindsByLinkText
		WebElement element11 = ((FindsByLinkText)driver).findElementByLinkText("Home Page");
		WebElement element12 = ((FindsByLinkText)driver).findElementByPartialLinkText("Home");
		List<WebElement> element13 = ((FindsByLinkText)driver).findElementsByLinkText("Home Page");
		Assert.assertEquals(element13.size(), 1);
		
		
		//WebDriver - findElement() method
		WebElement element14 = driver.findElement(By.xpath("//*[@type='button']"));
		WebElement element15 = driver.findElement(By.className("belowcenter"));
		WebElement element16 = driver.findElement(By.id("secondajaxbutton"));
		
	}
}
