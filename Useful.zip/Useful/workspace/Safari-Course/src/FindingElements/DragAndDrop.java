package FindingElements;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.internal.FindsByClassName;
import org.openqa.selenium.interactions.Action;

@SuppressWarnings("unused")
public class DragAndDrop {

	WebDriver driver;
	
	@Before
	public void setUp() {
		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile fp = profile.getProfile("default");
		driver = new FirefoxDriver(fp);
		driver.get("http://www.theautomatedtester.co.uk/demo2.html");
	}
	
//	@After
//	public void quit() {
//		driver.quit();
//	}
	
	@Test
	public void dragIt(){
		WebElement dragger = ((FindsByClassName)driver).findElementByClassName("draggable ui-draggable");
		WebElement dropper = ((FindsByClassName)driver).findElementByClassName("undropped");
		Actions builder = new Actions(driver);
		Action dragAndDrop = builder.clickAndHold(dragger)
		  .moveToElement(dropper)
		  .release(dragger)
		  .build();

		dragAndDrop.perform();
	}
	
}
