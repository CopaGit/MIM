package pageobjectpattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ChooseChapter {

	WebDriver selenium;
	public ChooseChapter(WebDriver selenium){
		this.selenium = selenium;
	}
	public void clickChapter(String chNo) {
		selenium.findElement(By.linkText("Chapter" + chNo)).click();
	}
}
