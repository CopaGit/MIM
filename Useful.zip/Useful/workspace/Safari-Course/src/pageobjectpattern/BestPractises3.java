package pageobjectpattern;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

@SuppressWarnings("unused")
public class BestPractises3 {
	  WebDriver selenium;

	  @Before
	  public void setUp(){
	    selenium = new FirefoxDriver();
	  }

	  @After
	 public void tearDown(){
	  selenium.quit();
	 }
	      

	  @Test
	  public void ShouldLoadTheHomePageAndThenCheckButtonOnChapter2(){
		   // selenium.get("http://book.theautomatedtester.co.uk");
		  // HomePage hp = new HomePage(selenium);
	 // System.out.println(hp.selenium.getTitle());
		  //  Chapter2 ch2 = hp.clickChapter2();
		  //  assertTrue(ch2.isButtonPresent("but1"));
	  Chapter2 ch2 = new Chapter2(selenium);
	  ch2.load();
	  System.out.println(ch2.isButtonPresent("but1"));
	  
	  
	  
	    
	   // ChooseChapter cc = new ChooseChapter(selenium);
	   // cc.clickChapter("3");
	  }
	}
