package test;

import static test.UI_Elements.*;
import static test.UI_Elements.emailId;
import static test.UI_Elements.incident_DashBoard_Access_Denied_OK_button;
import static test.UI_Elements.login_Button;
import static test.UI_Elements.passwd;
import static test.UI_Elements.password_Field;
import static test.UI_Elements.user_Name_Field;
import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class _05_06_Incident_Dashboard {
	
	public static AndroidDriver wd;
	
	@BeforeClass
	public static void setUp() throws MalformedURLException {
		File mim = new File ("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Android 19");
		
		capabilities.setCapability("app", mim.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
		capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
		capabilities.setCapability("noReset", true);
		wd = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
		
		//Opening the app and logging in
				//entering the user_name
				wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
				//entering the password
				wd.findElement(By.xpath(password_Field)).sendKeys(passwd);
				//Clicking on the login button
				wd.findElement(By.xpath(login_Button)).click();
				wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
				
				//Clicking OK on the 'Access Denied' message
				wd.findElement(By.xpath(incident_DashBoard_Access_Denied_OK_button)).click();
				

	}
	
	@Test
	public void test05_Incident_Dashboard_Refresh() {
		
		// Clicking in the Incident DashBoard Refresh button
		try {
		wd.findElement(By.xpath(incident_Dashboard_Refresh_Button)).click();
		} catch (NoSuchElementException n1) {
		wd.findElement(By.id("com.oraclecorp.eus.mobilemim:id/refreshImage")).click();
		}
		// Clicking on the Incident DashBoard Access Denied 'OK' button
		wd.findElement(By.xpath(incident_DashBoard_Access_Denied_OK_button)).click();
		
		// Output
		System.out.println("test05_Incident_Dashboard_Refresh");
		System.out.println("------------------.-----------");
		System.out.println("Passed - Incident Dashboard->'Refresh' button is working as intended");
		System.out.println();
		System.out.println();
		
	}
	
	@Test
	public void test06_Swiping_Between_Modules() throws InterruptedException {
		
		// Swiping from ID to EE module
		try {
			wd.swipe(900, 1000, 100, 1000, 3000);
		} catch (WebDriverException e) {
			wd.swipe(700, 1000, 100, 1000, 3000);
		}
		Thread.sleep(2000);
		// Swiping from EE to SL module
		try {
			wd.swipe(900, 1000, 100, 1000, 3000);
		} catch (WebDriverException e) {
			wd.swipe(700, 1000, 100, 1000, 3000);
		}
		Thread.sleep(2000);
		// Swiping from SL to EE module
		try {
			wd.swipe(100, 1000, 900, 1000, 3000);
		} catch (WebDriverException e) {
			wd.swipe(100, 1000, 700, 1000, 3000);
		}
		Thread.sleep(2000);
		// Swiping from EE to ID module
		try {
			wd.swipe(100, 1000, 900, 1000, 3000);
		} catch (WebDriverException e) {
			wd.swipe(100, 1000, 700, 1000, 3000);
		}
		Thread.sleep(2000);
		// Output
		System.out.println("test06_Swiping_Between_Modules");
		System.out.println("-----------------------------");
		System.out.println("Passed - Swiping between modules is working fine");
		System.out.println();
		System.out.println();
		
	}
	
	@AfterClass
	public static void tearDown(){
		wd.quit();
	}
	

}
