package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ 
	_01_LoginWithOutInternet.class,
	_02_LoginWithOnlyWifi.class,
	_03_04_LoginWithCredentials.class,
	_05_06_Incident_Dashboard.class,
	_11_18_Engagement_Escalation.class,
	_19_27_Scope_and_Level.class,
	_28_30_Logout_Functionality.class,
	 })
public class MobileMIM_All_Tests {

}
