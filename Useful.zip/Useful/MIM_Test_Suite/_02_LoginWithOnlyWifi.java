package test;

import static org.junit.Assert.*;
import static test.UI_Elements.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;



public class _02_LoginWithOnlyWifi {

	public static AndroidDriver wd;
	
		@BeforeClass
		public static void turnWifiOn() throws MalformedURLException {
					
		// Code for @BeforeClass	
		File mim = new File ("B:\\Selenium\\mobile apps\\Android\\EnableDisableWifi.apk");
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Android 19");
		
		capabilities.setCapability("app", mim.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.enabledisablewifi");
		capabilities.setCapability("appActivity", "com.enabledisablewifi.MainActivity");
		
		wd = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//Code for @Test
		//clicking enable WIFI button
		wd.findElement(By.id("com.enabledisablewifi:id/en")).click();
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
		//Code for @AfterClass
		wd.quit();
		
		}
		
		
	@Before
	public void setUp() throws MalformedURLException {
			
		File mim = new File ("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");
			
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Android 19");
		
		capabilities.setCapability("app", mim.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
		capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
			
		wd = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
		
	@Test
	public void test02_loginWithOnly_Wifi() throws Exception{
		
		//entering the user_name
		wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
		//entering the password
		wd.findElement(By.xpath(password_Field)).sendKeys(passwd);
		//Clicking on the login button
		wd.findElement(By.xpath(login_Button)).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//Asserting the "Could not connect to SSO server. Are you on VPN? alert message
		String alertMessage = wd.findElement(By.xpath(sso_Server_Error_Description)).getText();
		assertEquals("Could not contact SSO Server. Are you on VPN?", alertMessage);
		
		//Clicking on OK - in the "Could not connect to SSO server. Are you on VPN? alert message
		wd.findElement(By.xpath(sso_Server_Error_OK_Button)).click();
		
		System.out.println("test02_loginWithOnly_Wifi");
		System.out.println("----------------------------");
		System.out.println("Passed - Unable to login without VPN connection");
		System.out.println();
		System.out.println();
	
	
	}
	
	
	@AfterClass
	public static void tearDown() throws Exception {
		wd.quit();

	}
	
}

