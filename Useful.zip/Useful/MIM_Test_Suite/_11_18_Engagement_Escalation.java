package test;

import static org.junit.Assert.*;
import static test.UI_Elements.*;
import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.concurrent.TimeUnit;

import junit.framework.ComparisonFailure;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Ignore;

import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;


@SuppressWarnings("unused")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class _11_18_Engagement_Escalation {
public static AndroidDriver wd;


// using this function in test-case 11:
public void loggingInto_CSP_URL() throws InterruptedException{
	
	
	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	//Entering the user_name
	wd.findElement(By.xpath(csp_Username_Field)).sendKeys(emailId);
	//Entering the password
	wd.findElement(By.xpath(csp_Password_Field)).sendKeys(passwd);
	////Clicking on the sign_in button
	wd.findElement(By.xpath(csp_Sign_In_Button)).click();
	Thread.sleep(15000);
	
	//wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	//pulling the URL and asserting it for verification
	String csp_Link = wd.findElement(By.xpath(csp_URL)).getText();
	System.out.println("Displaying URL is: " + csp_Link);
	if (csp_Link.equals("https://gmp.oracle.com/csm/")) {
		assertEquals(csp_Link, "https://gmp.oracle.com/csm/");	
	} else if (csp_Link.equals("Search or type URL. https://gmp.oracle.com/csm/. Double tap to edit.")) {
		assertEquals(csp_Link, "Search or type URL. https://gmp.oracle.com/csm/. Double tap to edit.");
	} else {
		System.out.println("The Current Status Page Link is re-directing to a wrong link");
	}
	
	// CODE to clear Chrome  cache
	// Simulating a menu key event 
	wd.sendKeyEvent(82);
	// swiping to see the settings option
	wd.scrollTo("Settings");
	//wd.swipe(500, 750, 500, 550, 3000);
	//  clicking on the settings option
	wd.findElement(By.name("Settings")).click();
	// Now, clicking on the 'privacy' option under 'Advanced' category
	wd.findElement(By.name("Privacy")).click();
	// Then, clicking on the 'clear browsing data' option
	wd.findElement(By.name("Clear browsing data")).click();
	// Un_checking the browsing history option
	wd.findElement(By.name("Clear browsing history")).click();
	// Un_checking the cache option
	wd.findElement(By.name("Clear the cache")).click();
	// clicking on the 'clear' button
	wd.findElement(By.name("Clear")).click();
	wd.navigate().back();
	wd.navigate().back();
	
	
	wd.navigate().back();
	wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	wd.navigate().back();
	
}

// using this function in test-case 13:
public void touchdown_Email_Outage_Check(){
	// Clicking on the 'TO' recipient field
	wd.findElement(By.xpath(eot_To_Field)).click();
	// Pulling the emailAlias and asserting it for verification
	String emailAlias = wd.findElement(By.xpath(eot_Email_Alias)).getText();
	assertEquals(emailAlias, "outages_ww");
	// Pulling the emailId and asserting it for verification
	String emailId = wd.findElement(By.xpath(eot_Email_Id)).getText();
	assertEquals(emailId, "outages_ww@oracle.com");
	wd.navigate().back();
	wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	wd.navigate().back();
}

//using this function in test-case 14:
public void loggingInto_Solution_710631_URL() throws InterruptedException{
	
	
	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	//Entering the user_name
	wd.findElement(By.xpath(csp_Username_Field)).sendKeys(emailId);
	//Entering the password
	wd.findElement(By.xpath(csp_Password_Field)).sendKeys(passwd);
	////Clicking on the sign_in button
	wd.findElement(By.xpath(csp_Sign_In_Button)).click();
	Thread.sleep(9000);
	
	//wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	//pulling the URL and asserting it for verification
	String kb_Link = wd.findElement(By.xpath(kb_URL)).getText();
	System.out.println("Displaying URL is: " + kb_Link);
	if (kb_Link.equals("my.oracle.com/site/git/1591/4869/cnt710631")) {
		assertEquals(kb_Link, "my.oracle.com/site/git/1591/4869/cnt710631");	
	} else if (kb_Link.equals("Search or type URL. my.oracle.com/site/git/1591/4869/cnt710631. Double tap to edit.")) {
		assertEquals(kb_Link, "Search or type URL. my.oracle.com/site/git/1591/4869/cnt710631. Double tap to edit.");
	} else {
		System.out.println("The Current Status Page Link is re-directing to a wrong link");
	}
	
	// CODE to clear Chrome  cache
	// Simulating a menu key event 
	wd.sendKeyEvent(82);
	// swiping to see the settings option
	wd.scrollTo("Settings");
	//wd.swipe(500, 750, 500, 550, 3000);
	//  clicking on the settings option
	wd.findElement(By.name("Settings")).click();
	// Now, clicking on the 'privacy' option under 'Advanced' category
	wd.findElement(By.name("Privacy")).click();
	// Then, clicking on the 'clear browsing data' option
	wd.findElement(By.name("Clear browsing data")).click();
	// Un_checking the browsing history option
	wd.findElement(By.name("Clear browsing history")).click();
	// Un_checking the cache option
	wd.findElement(By.name("Clear the cache")).click();
	// clicking on the 'clear' button
	wd.findElement(By.name("Clear")).click();
	wd.navigate().back();
	wd.navigate().back();
	
	
	wd.navigate().back();
	wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	wd.navigate().back();
	
}



	@BeforeClass
	public static void setUp() throws MalformedURLException {
		File mim = new File ("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Android 19");
		
		capabilities.setCapability("app", mim.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
		capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
		capabilities.setCapability("noReset", true);
		wd = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
		
		//Opening the app and logging in
				//entering the user_name
				wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
				//entering the password
				wd.findElement(By.xpath(password_Field)).sendKeys(passwd);
				//Clicking on the login button
				wd.findElement(By.xpath(login_Button)).click();
				wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
				
				//Clicking OK on the 'Access Denied' message
				wd.findElement(By.xpath(incident_DashBoard_Access_Denied_OK_button)).click();
				try {wd.findElement(By.xpath(engagement_Escalation_Tab)).click();}
				catch (NoSuchElementException n2) {
					wd.findElement(By.name("Engagement & Escalation")).click();
				}

	}
	
	
	@Test
	public void test11_EE_Current_Status_Page() throws InterruptedException {
		//clicking on the current status page link
		wd.findElement(By.xpath(current_Status_Page_Link)).click();
		
		
		
			if (wd.findElement(By.xpath(complete_Action_Using)).isDisplayed() && wd.findElement(By.name("Chrome")).isDisplayed()) {
						
				        try {
				        	// clicking on the Chrome browser option
				        	 wd.findElement(By.name("Chrome")).click();
				        	// clicking on the Just Once option
				        	// Incase, Chrome browser is already selected and this Just once
				        	// element is not present - the control will go to catch block
				        	wd.findElement(By.name("Just once")).click();
				        	this.loggingInto_CSP_URL();
				        } catch (NoSuchElementException e) {
				        	System.out.println("Chrome browser is already selected");
				        	this.loggingInto_CSP_URL();
				        	}
				               
					} else {
						System.out.println("Chrome browser is NOT installed on Device");						
					}
							
		
		System.out.println("test11_EE_Current_Status_Page");
		System.out.println("-----------------------------");
		System.out.println("Passed - Current Status Page working as intended");
		System.out.println();
		System.out.println();
	}
	
	
	@Test
	public void test12_EE_Current_Status_Posting_Guidelines() throws InterruptedException {
		//clicking on the current_Status_Posting_Guidelines_Link
		wd.findElement(By.xpath(current_Status_Posting_Guidelines_Link)).click();
		
		if (wd.findElement(By.xpath(complete_Action_Using)).isDisplayed() && wd.findElement(By.name("Chrome")).isDisplayed()) {
			
	        try {
	        	// clicking on the Chrome browser option
	        	 wd.findElement(By.name("Chrome")).click();
	        	// clicking on the Just Once option
	        	// In case, Chrome browser is already selected and this Just once
	        	// element is not present - the control will go to catch block
	        	wd.findElement(By.name("Just once")).click();
	        	Thread.sleep(9000);
	        	} catch (NoSuchElementException e) {
	        	Thread.sleep(9000);
	        	}
	         
		} else {
			System.out.println("Chrome browser is NOT installed on Device");						
		}
		
		//pulling the URL and asserting it for verification
		String cspg_Link = wd.findElement(By.xpath(cspg_URL)).getText();
		System.out.println("Displaying URL is: " + cspg_Link);
		if (cspg_Link.equals("my.oracle.com/site/git/1591/4869/cnt1271607")) {
			assertEquals(cspg_Link, "my.oracle.com/site/git/1591/4869/cnt1271607");	
		} else if (cspg_Link.equals("Search or type URL. my.oracle.com/site/git/1591/4869/cnt1271607. Double tap to edit.")) {
			assertEquals(cspg_Link, "Search or type URL. my.oracle.com/site/git/1591/4869/cnt1271607. Double tap to edit.");
		} else {
			System.out.println("The Current Status Page Link is re-directing to a wrong location");
		}
		
		wd.navigate().back();
		
		System.out.println("test12_EE_Current_Status_Posting_Guidelines");
		System.out.println("-------------------------------------------");
		System.out.println("Passed - Current Status Posting Guidelines page working as intended");
		System.out.println();
		System.out.println();
		
	}
	
		
	
	//JavascriptExecutor js =(JavascriptExecutor)wd.executeScript("mobile: swipe", new HashMap<String, Double>() {{ put("touchCount", (double) 1); put("startX", (double) 524); put("startY", (double) 1512); put("endX", (double) 530); put("endY", (double) 832); put("duration", 1.296348); }});

	
	@Test
	public void test13_EE_Email_Outage_Team() {
		//clicking on the Email_Outage_Team_Link
		wd.findElement(By.xpath(email_Outage_Team_Button)).click();
		
		try {
			// if the Complete Action Using Dialog pop ups
			if (wd.findElement(By.xpath(complete_Action_Using)).isDisplayed() && wd.findElement(By.xpath(eot_Send_Email_Button)).isDisplayed()) {
					// Clicking on the touch down send email icon
					wd.findElement(By.name("Send Email")).click();
					// clicking on the Just Once option
					// if this element is NOT available at the time of testing
					// the control will go to the catch block
					wd.findElement(By.xpath(eot_Just_Once_Button)).click();
					
					// using the function created above
					//this.touchdown_Email_Outage_Check();
					// Clicking on the 'TO' recipient field
					wd.findElement(By.xpath(eot_To_Field)).click();
					// Pulling the emailAlias and asserting it for verification
					String emailAlias = wd.findElement(By.xpath(eot_Email_Alias)).getText();
					assertEquals(emailAlias, "outages_ww");
					// Pulling the emailId and asserting it for verification
					String emailId = wd.findElement(By.xpath(eot_Email_Id)).getText();
					assertEquals(emailId, "outages_ww@oracle.com");
					wd.navigate().back();
					wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					wd.navigate().back();
				} else {
					System.out.println("Touch Down Email is not configured");
				}
				} catch (NoSuchElementException e){
						// Displaying the information to the output
						System.out.println("Touch Down Send Email option is already selected");
						//this.touchdown_Email_Outage_Check();
						// Clicking on the 'TO' recipient field
						wd.findElement(By.xpath(eot_To_Field)).click();
						// Pulling the emailAlias and asserting it for verification
						String emailAlias = wd.findElement(By.xpath(eot_Email_Alias)).getText();
						assertEquals(emailAlias, "outages_ww");
						// Pulling the emailId and asserting it for verification
						String emailId = wd.findElement(By.xpath(eot_Email_Id)).getText();
						assertEquals(emailId, "outages_ww@oracle.com");
						wd.navigate().back();
						wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
						wd.navigate().back();
						
		}
		
				
		System.out.println("test13_EE_Email_Outage_Team");
		System.out.println("-------------------------------------------");
		System.out.println("Passed - Email Outage Team option is working as intended");
		System.out.println();
		System.out.println();
			
	}
	
	
	@Test
	public void test14_EE_Solutions_710631() throws InterruptedException {
		//clicking on the Solutions_710631_Link
		wd.findElement(By.xpath(solution_710631_Link)).click();
		
		if (wd.findElement(By.xpath(complete_Action_Using)).isDisplayed() && wd.findElement(By.name("Chrome")).isDisplayed()) {
			
	        try {
	        	// clicking on the Chrome browser option
	        	 wd.findElement(By.name("Chrome")).click();
	        	// clicking on the Just Once option
	        	// Incase, Chrome browser is already selected and this Just once
	        	// element is not present - the control will go to catch block
	        	wd.findElement(By.name("Just once")).click();
	        	this.loggingInto_Solution_710631_URL();
	        } catch (NoSuchElementException e) {
	        	System.out.println("Chrome browser is already selected");
	        	this.loggingInto_Solution_710631_URL();
	        	}
	               
		} else {
			System.out.println("Chrome browser is NOT installed on Device");						
		}
		
	
		System.out.println("test14_EE_Solutions_710631");
		System.out.println("-------------------------------------------");
		System.out.println("Passed - Solutions 710631 page working as intended");
		System.out.println();
		System.out.println();
		
	}
	
	
	@Test
	public void test15_EE_Call_Severity_Hotline() {
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		// Clicking on the call AMER hot line option
		wd.findElement(By.xpath(AMER_Call_Button)).click();
		// Clicking on the textPlus calling option
		wd.findElement(By.name("textPlus")).click();
		// Clicking on the Cancel Call
		wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
				
		// Clicking on the call EMEA hot line option
		wd.findElement(By.xpath(EMEA_Call_Button)).click();
		// Clicking on the textPlus calling option
		wd.findElement(By.name("textPlus")).click();
		// Clicking on the Cancel Call
		wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		// Clicking on the call APAC hot line option
		wd.findElement(By.xpath(APAC_Call_Button)).click();
		// Clicking on the textPlus calling option
		wd.findElement(By.name("textPlus")).click();
		// Clicking on the Cancel Call
		wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		System.out.println("test15_EE_Call_Severity_Hotline");
		System.out.println("-------------------------------------------");
		System.out.println("Passed - Calling Severity Hotline works fine.");
		System.out.println();
		System.out.println();
		}
	
	
	
	@Test
	public void test16_EE_Email_MIM_Team() {
		//clicking on the Email_MIM_Team_Link
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		wd.findElement(By.xpath(email_MIM_Team_Button)).click();
		
		// Clicking on the touch down send email icon
		wd.findElement(By.name("Send Email")).click();
		// Clicking on the 'To' field
		wd.findElement(By.xpath(spoc_To_Field)).click();
		// Pulling the spocAlias and asserting it for verification
		String spocAlias = wd.findElement(By.xpath(spoc_Email_Alias)).getText();
		assertEquals(spocAlias, "mim-team_ww_grp");
		// Pulling the spocId and asserting it for verification
		String spocId = wd.findElement(By.xpath(spoc_Email_id)).getText();
		assertEquals(spocId, "mim-team_ww_grp@oracle.com");
		wd.navigate().back();
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		wd.navigate().back();
			
		System.out.println("test16_EE_Email_MIM_Team");
		System.out.println("-------------------------------------------");
		System.out.println("Passed - Email MIM Team option is working as intended");
		System.out.println();
		System.out.println();
			
	}
	
	
	@Test
	public void test17_EE_Chatroom_MIM() {
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Clicking on the Chat room button
		wd.findElement(By.xpath(chat_Room_Button)).click();
		// Asserting Chat Room Title message
		String chatroom_Title = wd.findElement(By.xpath(chat_Room_Title)).getText();
		assertEquals(chatroom_Title, "Chat room address added to clipboard.");
		// Asserting Chat Room Description
		String chatroom_Desc = wd.findElement(By.xpath(chat_Room_Description)).getText();
		assertEquals(chatroom_Desc, "The Chat Room address has been copied to your clipboard. You can paste the address into your Instant Messaging App.");
		// Clicking OK button on the Chat Room message
		wd.findElement(By.xpath(chat_Room_OK_Button)).click();
		
		
		System.out.println("test17_EE_Chatroom_MIM");
		System.out.println("-------------------------------------------");
		System.out.println("Passed - Chatroom MIM option is working as intended");
		System.out.println();
		System.out.println();
		}
	
	
	@Test
	public void test18_EE_Contact_List() {
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Swiping to see the contact list option
		try {
			wd.swipe(530, 1700, 530, 1365, 3000);
		} catch (WebDriverException e) {
			wd.swipe(350, 1100, 350, 950, 3000);
		}
		// Clicking on the Contact List option
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		wd.findElement(By.name("Contact list")).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		// Testing FIRST LEVEL CONTACT - Jyothi Ballurgi (EMEA)
		
		// clicking on Jyothi Ballurgi contact
		wd.findElement(By.xpath(jyothi_Ballurgi)).click();
		
		// clicking on Jyothi Ballurgi - Work Phone
		wd.findElement(By.xpath(jyothi_Work_Phone)).click();
		// Clicking on the textPlus calling option
		wd.findElement(By.name("textPlus")).click();
		// Clicking on the Cancel Call
		wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		// clicking on Jyothi Ballurgi - Cell Phone
		wd.findElement(By.xpath(jyothi_Cell_Phone)).click();
		// Clicking on the textPlus calling option
		wd.findElement(By.name("textPlus")).click();
		// Clicking on the Cancel Call
		wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
		// Clicking on the Contact List back button
		wd.findElement(By.xpath(CL_Back_button)).click();
		
		// Testing SECOND LEVEL CONTACT - Catherine Miller (AMER)
		
				// clicking on Catherine Miller contact
				wd.findElement(By.xpath(catherine_Miller)).click();
				// clicking on Catherine Miller - Work Phone
				wd.findElement(By.xpath(catherine_Work_Phone)).click();
				// Clicking on the textPlus calling option
				wd.findElement(By.name("textPlus")).click();
				// Clicking on the Cancel Call
				wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
				wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				
				// clicking on Catherine Miller - Cell Phone
				wd.findElement(By.xpath(catherine_Cell_Phone)).click();
				// Clicking on the textPlus calling option
				wd.findElement(By.name("textPlus")).click();
				// Clicking on the Cancel Call
				wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
				wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						
				// Clicking on the Contact List back button
				wd.findElement(By.xpath(CL_Back_button)).click();
		
	
				
				
		// Testing SECOND LEVEL CONTACT - Tim Padovan (APAC)
				
				// clicking on Tim Padovan contact
				wd.findElement(By.xpath(tim_Padovan)).click();
				// clicking on Tim Padovan - Work Phone
				wd.findElement(By.xpath(tim_Work_Phone)).click();
				// Clicking on the textPlus calling option
				wd.findElement(By.name("textPlus")).click();
				// Clicking on the Cancel Call
				wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
				wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				
				// clicking on Tim Padovan - Cell Phone
				wd.findElement(By.xpath(tim_Cell_Phone)).click();
				// Clicking on the textPlus calling option
				wd.findElement(By.name("textPlus")).click();
				// Clicking on the Cancel Call
				wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
				wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						
				// Clicking on the Contact List back button
				wd.findElement(By.xpath(CL_Back_button)).click();
		

				
				
		// Testing SECOND LEVEL CONTACT - John Owens (EMEA)
				
				// clicking on John Owens contact
				wd.findElement(By.xpath(John_Owens)).click();
				// clicking on John Owens - Work Phone
				wd.findElement(By.xpath(John_Work_Phone)).click();
				// Clicking on the textPlus calling option
				wd.findElement(By.name("textPlus")).click();
				// Clicking on the Cancel Call
				wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
				wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				
				// clicking on John Owens - Cell Phone
				wd.findElement(By.xpath(John_Cell_Phone)).click();
				// Clicking on the textPlus calling option
				wd.findElement(By.name("textPlus")).click();
				// Clicking on the Cancel Call
				wd.findElement(By.id("com.gogii.textplus:id/ignore_call")).click();
				wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						
				// Clicking on the Contact List back button
				wd.findElement(By.xpath(CL_Back_button)).click();
		
		// Clicking on the Engagement and Escalation Back Button
		wd.findElement(By.xpath(EE_Back_Button)).click();
	
		System.out.println("test18_EE_Contact_List");
		System.out.println("-------------------------------------------");
		System.out.println("Passed - Contact List option is working as intended");
		System.out.println();
		System.out.println();
		}
	
	
	
	@AfterClass
	public static void tearDown() throws Exception {
		wd.quit();
	}
	
}
