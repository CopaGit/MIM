package test;

import static org.junit.Assert.*;

import static test.UI_Elements.*;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ScrollsTo;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;


@SuppressWarnings("unused")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class _19_27_Scope_and_Level {
	
	static AndroidDriver wd;
	
	@BeforeClass
	public static void setUp() throws MalformedURLException {
		
		File app = new File("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Samsung");
		
		capabilities.setCapability("app", app.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
		capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
		capabilities.setCapability("noReset", true);
		
		wd = new AndroidDriver (new URL ("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//APP_LOGIN
		//entering the user_name
		wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
		//entering the password
		wd.findElement(By.xpath(password_Field)).sendKeys(passwd);
		//Clicking on the login button
		wd.findElement(By.xpath(login_Button)).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				
		//Clicking OK on the 'Access Denied' message
		wd.findElement(By.xpath(incident_DashBoard_Access_Denied_OK_button)).click();
		
		//clicking on the Scope and Level Tab
		wd.findElement(By.xpath(scope_Level_Tab)).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}
	
	
	@Test
	public void test19_SL_Definition() {
		//clicking on the definition sub tab
		//wd.findElement(By.xpath(definition_Sub_Tab)).click();
		
		//Asserting the complete definition_text in 3 parts
		assertEquals(wd.findElement(By.xpath(definition_Description1)).getText(), "The Global IT Major Incident Management (MIM) process handles critical incidents requiring a response above and beyond the normal incident management process.");
		assertEquals(wd.findElement(By.xpath(definition_Description2)).getText(), "While these major incidents follow the normal incident lifecycle, the MIM Process provides the increased coordination, escalation, communication, and resources these high-priority incidents require. ");
		assertEquals(wd.findElement(By.xpath(definition_Description3)).getText(), "SCOPE : Identified Global IT-managed critical infrastructure, applications, or services when service is disrupted or impaired to the extent that work cannot reasonably continue and the disruption exceeds any pre-defined time-based threshold.");
		//output
				System.out.println("test19_SL_Definition");
				System.out.println("------------------------");
				System.out.println("Passed - Definition is present with appropriate text");
				System.out.println();
				System.out.println();
		
	}
	
	
	@Test
	public void test20_SL_Level_0_Minor(){
		//clicking on the Levels sub tab
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		wd.findElement(By.xpath(levels_Sub_Tab)).click();
		//clicking on the level_0_Minor_Button
		wd.findElement(By.xpath(level_0_Minor_Button)).click();
		//Asserting the contents of the Level 0 - Minor option
		assertEquals(wd.findElement(By.xpath(level_0_Title)).getText(), "Level 0 - Minor");
		assertEquals(wd.findElement(By.xpath(level_0_Decription)).getText(), "Incident or impact to GIT that demands additional handling and notification");
		assertEquals(wd.findElement(By.xpath(level_0_Awareness)).getText(), "Support teams");
		assertEquals(wd.findElement(By.xpath(level_0_Output)).getText(), "CSM outage board "+"\n"+"Handled as Severity 1 incident");
		wd.navigate().back();
		//output
				System.out.println("test20_SL_Level_0_Minor");
				System.out.println("------------------------");
				System.out.println("Passed - Level 0 Minor displays correct details");
				System.out.println();
				System.out.println();
	}
	
	
	@Test
	public void test21_SL_Level_1_Major(){
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		//clicking on the Level 1 - Major_Button
		wd.findElement(By.xpath(level_1_Major_Button)).click();
		//Asserting the contents of the Level 1 - Major option
		assertEquals(wd.findElement(By.xpath(level_1_Title)).getText(), "Level 1 - Major");
		assertEquals(wd.findElement(By.xpath(level_1_Decription)).getText(), "SINGLE KEY AREA impacted \n"+  "or \n"+ "declared by IRM director");
		assertEquals(wd.findElement(By.xpath(level_1_Awareness)).getText(), "IRM director");
		assertEquals(wd.findElement(By.xpath(level_1_Output)).getText(), "Full major incident procedure "+"\n"+"RCCA is by exception only");
		wd.navigate().back();
		//output
				System.out.println("test21_SL_Level_1_Major");
				System.out.println("------------------------");
				System.out.println("Passed - Level 1 Major displays correct details");
				System.out.println();
				System.out.println();
	}
	
	
	
	@Test
	public void test22_SL_Level_2_Critical(){
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		//clicking on the Level 2 - Critical_Button
		wd.findElement(By.xpath(level_2_Critical_Button)).click();
		//Asserting the contents of the Level 2 - Critical option
		assertEquals(wd.findElement(By.xpath(level_2_Title)).getText(), "Level 2 - Critical");
		assertEquals(wd.findElement(By.xpath(level_2_Decription)).getText(), "MULTIPLE KEY AREAS impacted \n"+  "or \n"+ "declared by IRM director");
		assertEquals(wd.findElement(By.xpath(level_2_Awareness)).getText(), "CCMT");
		assertEquals(wd.findElement(By.xpath(level_2_Output)).getText(), "Full major incident procedure "+"\n"+"RCCA is mandatory");
		wd.navigate().back();
		//output
				System.out.println("test22_SL_Level_2_Critical");
				System.out.println("------------------------");
				System.out.println("Passed - Level 2 Critical displays correct details");
				System.out.println();
				System.out.println();
	}
	
	
	@Test
	public void test23_SL_Level_3_Catastrophic(){
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		//clicking on the Level 3 - Catastrophic_Button
		wd.findElement(By.xpath(level_3_Catastrophic_Button)).click();
		//Asserting the contents of the Level 3 - Catastrophic option
		assertEquals(wd.findElement(By.xpath(level_3_Title)).getText(), "Level 3 - Catastrophic");
		assertEquals(wd.findElement(By.xpath(level_3_Decription)).getText(), "MULTIPLE KEY AREAS impacted \n"+  "and \n"+ "declared w/GIT Risk Management");
		assertEquals(wd.findElement(By.xpath(level_3_Awareness)).getText(), "CCMT, PR, Legal");
		assertEquals(wd.findElement(By.xpath(level_3_Output)).getText(), "Full major incident procedure "+"\n"+"RCCA is mandatory");
		wd.navigate().back();
		//output
				System.out.println("test23_SL_Level_3_Catastrophic");
				System.out.println("------------------------");
				System.out.println("Passed - Level 3 Catastrophic displays correct details");
				System.out.println();
				System.out.println();
	}
	
	
	@Test
	public void test24_SL_Sensitive_Incident(){
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		//clicking on the Sensitive_Incident_Button
		wd.findElement(By.xpath(sensitive_Incident_Button)).click();
		//Asserting the contents of the Sensitive_Incident option
		assertEquals(wd.findElement(By.xpath(sensitive_Incident_Title)).getText(), "Sensitive Incident");
		assertEquals(wd.findElement(By.xpath(sensitive_Incident_description)).getText(), "Any incident SUSPECTED AND/OR CONFIRMED AS BEING SENSITIVE in nature, or any breach such as DoS, DDoS, Virus, Data Breach");
		assertEquals(wd.findElement(By.xpath(sensitive_Incident_Awareness)).getText(), "CCMT, PR, Legal");
		assertEquals(wd.findElement(By.xpath(sensitive_Incident_Output)).getText(), "Special handling procedures "+"\n"+"Restricted communications");
		wd.navigate().back();
		//output
				System.out.println("test24_SL_Sensitive_Incident");
				System.out.println("------------------------");
				System.out.println("Passed - Sensitive Incident displays correct details");
				System.out.println();
				System.out.println();
	}
	
	
	@Test
	public void test25_SL_KeyAreas_Application() {
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		// clicking on the key areas sub tab
		wd.findElement(By.xpath(key_Areas_Sub_Tab)).click();
		// Verifying all the elements under category - APPLICATIONS
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(GESDB)).getText(), "GESDB");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(GCCA)).getText(), "GCCA");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(intercall)).getText(), "Intercall");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(myHelp_SupportDesk)).getText(), "MyHelp SupportDesk");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(EM)).getText(), "EM");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(GMP)).getText(), "GMP");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(Monolith)).getText(), "Monolith");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(ITAS)).getText(), "ITAS(30min))");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(MyDesktop)).getText(), "MyDesktop(120min)");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.xpath(MyDevice)).getText(), "MyDevice/MDM(120min)");
		
		// Swiping up to the element 'Communications'
		try {
			wd.swipe(500, 1800, 500, 500, 3500);
		} catch (WebDriverException e) {
			wd.swipe(350, 1250, 350, 350, 3500);
		}
		
		//output
		System.out.println("test25_SL_KeyAreas_Application");
		System.out.println("------------------------");
		System.out.println("Passed - KeyAreas->Application displays correct details");
		System.out.println();
		System.out.println();
		
	}
	
	@Test
	public void test26_SL_KeyAreas_Locations() {
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		// Verifying all the elements under category - LOCATIONS
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("Public Events")).getText(), "Public Events");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("Data Centers")).getText(), "Data Centers");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("Tier 1 Offices")).getText(), "Tier 1 Offices");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("Tier 2 Offices")).getText(), "Tier 2 Offices");
		
		//output
				System.out.println("test26_SL_KeyAreas_Locations");
				System.out.println("------------------------");
				System.out.println("Passed - KeyAreas->Locations displays correct details");
				System.out.println();
				System.out.println();
		
	}
		
	
	@Test
	public void test27_SL_KeyAreas_Services() {
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		// Verifying all the elements under category - Services
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("Enterprise Network")).getText(), "Enterprise Network");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("(WAN and LAN)")).getText(), "(WAN and LAN)");
		
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("Core Backbone")).getText(), "Core Backbone");
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("(Primary or Secondary)")).getText(), "(Primary or Secondary)");
		 
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("Data Center Network")).getText(), "Data Center Network");
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("OCCN")).getText(), "OCCN");
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);		
		assertEquals(wd.findElement(By.name("Communications")).getText(), "Communications");
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("(Voice/Video)")).getText(), "(Voice/Video)");
		
		try {
			wd.swipe(500, 1700, 500, 1030, 3500);
		} catch (WebDriverException e) {
			wd.swipe(350, 1000, 350, 500, 3500);
		}
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("DNS")).getText(), "DNS");
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("OU Connectivity")).getText(), "OU Connectivity");
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("(VPN, LVC)")).getText(), "(VPN, LVC)");
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("VDI or SunRay")).getText(), "VDI or SunRay");
		
		wd.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		assertEquals(wd.findElement(By.name("WiFi(30min)")).getText(), "WiFi(30min)");
		
		//output
		System.out.println("test27_SL_KeyAreas_Services");
		System.out.println("------------------------");
		System.out.println("Passed - KeyAreas->Services displays correct details");
		System.out.println();
		System.out.println();
	}
	
	@AfterClass
	public static void tearDown() {
	wd.quit();
}
	
}
