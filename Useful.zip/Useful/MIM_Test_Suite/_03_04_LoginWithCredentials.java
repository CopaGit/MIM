package test;

import static org.junit.Assert.*;
import static test.UI_Elements.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.android.AndroidDriver;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.DesiredCapabilities;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class _03_04_LoginWithCredentials {

	public static AndroidDriver wd;
	
		
	@BeforeClass
	public static void VpnSetUp() throws MalformedURLException {
				
		
				//code for VPN client setUp()
				File app = new File ("B:\\Selenium\\mobile apps\\Android\\app.openconnect-1.apk");
				
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability("platformName", "Android");
				capabilities.setCapability("platformVersion", "4.4.2");
				capabilities.setCapability("deviceName", "Android19");
				
				capabilities.setCapability("app", app.getAbsolutePath());
				capabilities.setCapability("appPackage", "app.openconnect");
				capabilities.setCapability("appActivity", "app.openconnect.MainActivity");
				capabilities.setCapability("noReset", true);
				
				wd = new AndroidDriver (new URL ("http://127.0.0.1:4723/wd/hub"), capabilities);
				wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				//code for creating Oracle VPN profile to connect
				//Clicking on the '+' button at the bottom of the screen to add the server name
				wd.findElement(By.name("Add")).click();
				//Entering the server name details
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")).sendKeys("myaccess.oraclevpn.com");
				//Then, clicking 'OK' button
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.Button[2]")).click();
				//Now, navigating one (screen) activity back
				wd.navigate().back();
				wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				//Clicking on the Oracle VPN option
				try {
				wd.findElement(By.xpath("//android.view.View[1]/android.widget.FrameLayout[2]/android.widget.LinearLayout[1]/android.widget.ListView[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")).click();
				} catch (NoSuchElementException n) {
					wd.findElement(By.id("app.openconnect:id/vpn_item_title")).click();
				}
				
				// conditional code for whether to select 'I trust the connection' or
				//to proceed to click 'Just now' button
					
				
				boolean isCheckBoxPresent;
				try {
				wd.findElement(By.id("com.android.vpndialogs:id/check"));
				   isCheckBoxPresent = true;
				} catch (NoSuchElementException e) {
					isCheckBoxPresent = false;
				}
				if (isCheckBoxPresent) {
					// 1_Clicking on the 'I trust this application' checkBox.
					wd.findElement(By.id("com.android.vpndialogs:id/check")).click();
					// 2_Clicking on OK below the 'I trust this application' checkBox.
					wd.findElement(By.id("android:id/button1")).click();
					// 3_Then, clicking on the 'Just Once' button, finally.
					wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.Button[2]")).click();
				}
				else {
				//Clicking on the 'Just Once' button, directly.
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.Button[2]")).click();
				}
				
				
				//Entering the VPN user_name
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")).sendKeys("fhassan_in");
				//Entering the password
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[2]/android.widget.EditText[1]")).sendKeys("Yyyy1431#");
				//Un_checking the save password check_box
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.CheckBox[1]")).click();
				//Clicking on the 'OK' button to connect to VPN
				wd.findElement(By.xpath("//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.Button[2]")).click();

				
				//code for @After
				wd.quit();
				
			
		// Code for MIM setUp()		
		File mim = new File ("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");
			
		capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Android 19");
		
		capabilities.setCapability("app", mim.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
		capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
			
		wd = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
		
	@Test
	public void test03_loginWith_Invalid_crendential() throws Exception{
		
		//entering the user_name
		wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
		//entering the password
		wd.findElement(By.xpath(password_Field)).sendKeys("temp");
		//Clicking on the login button
		wd.findElement(By.xpath(login_Button)).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//Asserting the "Check User_name and Password" message
		String loginFailed = wd.findElement(By.xpath(sso_Login_failed_Description)).getText();
		assertEquals("SSO Login failed. Check username and password.", loginFailed);
				
		//Then, clicking OK on the message
		wd.findElement(By.xpath(sso_Login_failed_OK_Button)).click();
		
		System.out.println("test03_loginWith_Invalid_crendential");
		System.out.println("--------------------------------------");
		System.out.println("Passed - Unable to login with Invalid Crendetials");
		System.out.println();
		System.out.println();
	}
	
	@Test
	public void test04_loginWith_Valid_Credentials() throws Exception{
		
		//entering the user_name
		wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
		//entering the password
		wd.findElement(By.xpath(password_Field)).sendKeys(passwd);
		//Clicking on the login button
		wd.findElement(By.xpath(login_Button)).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		//Clicking OK on the 'Access Denied' message
		wd.findElement(By.xpath(incident_DashBoard_Access_Denied_OK_button)).click();
		
		
		System.out.println("test04_loginWith_Valid_Credentials");
		System.out.println("--------------------------------------");
		System.out.println("Passed - Able to login with Valid Crendetials");
		System.out.println();
		System.out.println();
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//clicking on the 'logout' button
		wd.navigate().back();
		//wd.findElement(By.xpath(logout_Button)).click();
		//clicking on YES on the Do you want to logout message
		wd.findElement(By.xpath(logout_YES)).click();
		
	}
	
	@AfterClass
	public static void tearDown() {
		wd.quit();
		}
	}
	

