package test;
import static test.UI_Elements.*;
import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class _28_30_Logout_Functionality {	
		
		AndroidDriver wd;
		
		@Before
		public void setUp() throws MalformedURLException {
			File mim = new File ("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");
			
			DesiredCapabilities capabilities = new DesiredCapabilities();
			
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("platformVersion", "4.4.2");
			capabilities.setCapability("deviceName", "Android 19");
			
			capabilities.setCapability("app", mim.getAbsolutePath());
			capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
			capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
			capabilities.setCapability("noReset", true);
			wd = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
			wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
			
			//Opening the app and logging in
					//entering the user_name
					wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
					//entering the password
					wd.findElement(By.xpath(password_Field)).sendKeys(passwd);
					//Clicking on the login button
					wd.findElement(By.xpath(login_Button)).click();
					wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
					
					//Clicking OK on the 'Access Denied' message
					wd.findElement(By.xpath(incident_DashBoard_Access_Denied_OK_button)).click();
					

		}
		
		@Test
		public void test28_Logout_By_Logout_Button() {
			// Clicking on the Logout button
			wd.findElement(By.xpath(logout_Button)).click();
			// Clicking 'YES' button on the "Do you want to logout from MIM" message
			wd.findElement(By.xpath(logout_YES)).click();
			// Output
			System.out.println("test28_Logout_By_LogoutButton");
			System.out.println("------------------.-----------");
			System.out.println("Passed - Logged out successfully using 'logout' button.");
			System.out.println();
			System.out.println();
		}
		
		@Test
		public void test29_Logout_By_Back_Button() {
			
			// Clicking on the Device Back button
			wd.navigate().back();
			// Clicking 'YES' button on the "Do you want to logout from MIM" message
			wd.findElement(By.xpath(logout_YES)).click();
			// Output
			System.out.println("test29_Logout_By_BackButton");
			System.out.println("------------------.-----------");
			System.out.println("Passed - Logged out successfully using 'device back' button.");
			System.out.println();
			System.out.println();
			
		}
		
		
		@Test
		public void test30_Not_Logging_Out() {
			
			// Clicking on the Logout button
			wd.findElement(By.xpath(logout_Button)).click();
			// Clicking 'YES' button on the "Do you want to logout from MIM" message
			wd.findElement(By.xpath(logout_NO)).click();
			if (wd.findElement(By.xpath(incident_Dashboard_Refresh_Button)).isDisplayed()){
				// Output
				System.out.println("test30_Not_Logging_Out");
				System.out.println("------------------.-----------");
				System.out.println("Passed - Did not logout of the app - after choosing 'NO' option on the logout message");
				System.out.println();
				System.out.println();
			}
				
			
			
		}
		
		@After
		public void tearDown(){
			wd.quit();
		}
		

	}


