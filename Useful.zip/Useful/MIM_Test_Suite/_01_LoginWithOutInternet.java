package test;

import static org.junit.Assert.*;
import static test.UI_Elements.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;



public class _01_LoginWithOutInternet {
	public static AppiumDriver wd;
	
	@BeforeClass
	public static void setUp() throws MalformedURLException {
		File mim = new File ("B:\\Selenium\\mobile apps\\Android\\MobileMIM.apk");
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "4.4.2");
		capabilities.setCapability("deviceName", "Android 19");
		
		capabilities.setCapability("app", mim.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.oraclecorp.eus.mobilemim");
		capabilities.setCapability("appActivity", "com.oraclecorp.eus.mobilemim.Login");
		
		wd = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
	}
	
	@Test
	public void test01_loginWithout_Internet() {
		//entering the user_name
		wd.findElement(By.xpath(user_Name_Field)).sendKeys(emailId);
		//entering the password
		wd.findElement(By.xpath(password_Field)).sendKeys(passwd);
		//Clicking on the login button
		wd.findElement(By.xpath(login_Button)).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//Getting the first banner message - Major Incident Management
		String titleMessage1 = wd.findElement(By.xpath(major_Incident_Management_Title)).getText();
		assertEquals("Major Incident Management", titleMessage1);
	
		//Getting the second banner message - 
		String titleMessage2 = wd.findElement(By.xpath(sso_Login_title)).getText();
		assertEquals("SSO Login", titleMessage2);
		
		//output
		System.out.println("test01_loginWithout_Internet");
		System.out.println("-------------------------------");
		System.out.println("Passed - Unable to login without Internet");
		System.out.println();
		System.out.println();
	}
	
	
	@AfterClass
	public static void tearDown() throws Exception {
		wd.quit();
	}


	}
